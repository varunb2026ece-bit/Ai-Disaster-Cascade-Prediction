# CascadeGuard — Disaster Cascade Simulation Prototype

## Requirements
- Node.js 18 or newer
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local address shown in the terminal (typically http://localhost:5173).

## Production build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
Push this folder to a GitHub repository, then import the repository at https://vercel.com.
Vercel should detect Vite automatically. Build command: `npm run build`; output directory: `dist`.

## Notes
This is a frontend demonstration using synthetic data and heuristic calculations. It is not a validated disaster prediction model and must not be used for real emergency decisions.
