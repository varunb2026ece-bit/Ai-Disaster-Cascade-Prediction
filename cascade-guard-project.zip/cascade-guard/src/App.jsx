import { useState } from "react";
import {
  Activity, AlertTriangle, CloudRain, Waves, Mountain, Zap, Droplets,
  Map, GitBranch, Truck, FileText, LayoutDashboard, Settings,
  RefreshCw, ShieldAlert
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid
} from "recharts";
import "./App.css";

const initialResources = [
  { name: "Rescue teams", available: 20, allocated: 8 },
  { name: "Medical kits", available: 100, allocated: 35 },
  { name: "Food packages", available: 250, allocated: 90 },
  { name: "Water units", available: 200, allocated: 65 },
];

const locations = [
  { name: "River Valley", risk: 88, people: 2400 },
  { name: "Hill Sector", risk: 76, people: 1200 },
  { name: "Coastal Zone", risk: 61, people: 3200 },
  { name: "Town Center", risk: 35, people: 5400 },
];

const navigation = [
  ["Overview", LayoutDashboard],
  ["Simulation", Activity],
  ["Cascade graph", GitBranch],
  ["Risk map", Map],
  ["Resource allocation", Truck],
  ["Scenarios", CloudRain],
  ["Alerts", ShieldAlert],
  ["Reports & audit", FileText],
];

function Stat({ title, value, detail, icon: Icon, color }) {
  return (
    <div className="stat card">
      <div className="stat-top">
        <span>{title}</span>
        <span className="stat-icon" style={{ color }}>
          <Icon size={20} />
        </span>
      </div>
      <h2>{value}</h2>
      <p>{detail}</p>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState("Overview");
  const [rainfall, setRainfall] = useState(180);
  const [resources, setResources] = useState(initialResources);
  const [simulated, setSimulated] = useState(false);
  const [scenario, setScenario] = useState("Extreme rainfall");

  const risk = Math.min(99, Math.round(25 + rainfall * 0.35));
  const highRisk = locations.filter((x) => x.risk >= 70).length;

  const chartData = [
    { name: "Flood", risk: Math.min(99, rainfall * 0.48) },
    { name: "Landslide", risk: Math.min(99, rainfall * 0.38) },
    { name: "Power failure", risk: Math.min(99, rainfall * 0.27) },
    { name: "Contamination", risk: Math.min(99, rainfall * 0.32) },
  ];

  function runSimulation() {
    setSimulated(true);
    setResources((previous) =>
      previous.map((item) => ({
        ...item,
        allocated: Math.min(item.available, Math.ceil(item.available * risk / 200)),
      }))
    );
  }

  function resetSimulation() {
    setRainfall(180);
    setResources(initialResources);
    setSimulated(false);
    setScenario("Extreme rainfall");
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-logo"><Activity size={23} /></div>
          <div>
            <strong>CascadeGuard</strong>
            <small>DECISION SUPPORT</small>
          </div>
        </div>

        <div className="region"><span className="live-dot" />Western Ghats demo region</div>
        <p className="nav-label">WORKSPACE</p>
        {navigation.map(([label, Icon]) => (
          <button key={label} className={`nav-item ${page === label ? "active" : ""}`}
            onClick={() => setPage(label)}>
            <Icon size={18} /><span>{label}</span>
          </button>
        ))}
        <div className="sidebar-bottom"><Settings size={17} />Prototype environment</div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><span className="breadcrumb">Operations / </span><strong>{page}</strong></div>
          <span className="demo-badge">● DEMO MODE</span>
        </header>

        <div className="notice">
          <AlertTriangle size={17} />
          <span><strong>Prototype only.</strong> Synthetic data and heuristic models. Not for real emergency decision-making.</span>
        </div>

        <section className="heading">
          <div>
            <p className="eyebrow">DISASTER INTELLIGENCE PLATFORM</p>
            <h1>{page === "Overview" ? "Operations overview" : page}</h1>
            <p className="subtitle">Predict cascading disasters and coordinate emergency resources.</p>
          </div>
          <button className="secondary-button" onClick={resetSimulation}><RefreshCw size={16} /> Reset</button>
        </section>

        {page === "Overview" && <>
          <div className="stats-grid">
            <Stat title="Cascade risk" value={`${risk}%`} detail="Simulated regional risk" icon={Activity} color="#ef6b55" />
            <Stat title="High-risk locations" value={highRisk} detail="Locations requiring attention" icon={Map} color="#e8a23d" />
            <Stat title="Disaster pathways" value="4" detail="Potential secondary events" icon={GitBranch} color="#9a82f5" />
            <Stat title="Resource categories" value={resources.length} detail="Available for allocation" icon={Truck} color="#49b99a" />
          </div>

          <div className="content-grid">
            <section className="card simulation-card">
              <div className="section-head">
                <div><h3>Disaster simulation</h3><p>Adjust environmental conditions</p></div>
                <span className="tag">INTERACTIVE</span>
              </div>
              <label className="field-label">Active scenario</label>
              <select value={scenario} onChange={(e) => setScenario(e.target.value)}>
                <option>Extreme rainfall</option><option>River flooding</option>
                <option>Mountain landslide</option><option>Coastal storm</option>
              </select>
              <div className="slider-head"><label>Rainfall intensity</label><strong>{rainfall} mm</strong></div>
              <input type="range" min="0" max="250" value={rainfall}
                onChange={(e) => { setRainfall(Number(e.target.value)); setSimulated(false); }} />
              <div className="range-labels"><span>0 mm</span><span>250 mm</span></div>
              <div className="risk-result">
                <div><span className="muted">Estimated cascade risk</span><h2>{risk}%</h2></div>
                <span className={`risk-pill ${risk >= 70 ? "danger" : "warning"}`}>{risk >= 70 ? "Elevated risk" : "Moderate risk"}</span>
              </div>
              <button className="primary-button" onClick={runSimulation}><Activity size={17} />Run simulation</button>
              {simulated && <p className="success-message">Demo simulation completed. Resource estimates updated.</p>}
            </section>

            <section className="card chart-card">
              <div className="section-head"><div><h3>Secondary disaster risk</h3><p>Estimated risk by event type</p></div></div>
              <div className="chart">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ left: 12, right: 18 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#263448" />
                    <XAxis type="number" domain={[0, 100]} tick={{ fill: "#91a0b5", fontSize: 11 }} />
                    <YAxis type="category" dataKey="name" width={100} tick={{ fill: "#c1cada", fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: "#101b2b", border: "1px solid #304158", borderRadius: 8 }} />
                    <Bar dataKey="risk" fill="#4b91e2" radius={[0, 5, 5, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>

          <section className="card cascade-card">
            <div className="section-head"><div><h3>Disaster cascade pathways</h3><p>How one hazard may trigger secondary failures</p></div></div>
            <div className="cascade-flow">
              <div className="event rain"><CloudRain size={24} /><strong>Extreme rainfall</strong><small>Primary hazard</small></div>
              <div className="connector">→</div>
              <div className="event"><Waves size={23} /><strong>Flooding</strong><small>Water overflow</small></div>
              <div className="connector">→</div>
              <div className="event"><Mountain size={23} /><strong>Landslide</strong><small>Slope instability</small></div>
              <div className="connector">→</div>
              <div className="event"><Zap size={23} /><strong>Power failure</strong><small>Infrastructure impact</small></div>
              <div className="connector">→</div>
              <div className="event"><Droplets size={23} /><strong>Water contamination</strong><small>Public health risk</small></div>
            </div>
          </section>

          <section className="card locations-card">
            <div className="section-head">
              <div><h3>Vulnerable locations</h3><p>Synthetic demonstration data</p></div>
              <button className="text-button" onClick={() => setPage("Risk map")}>View all →</button>
            </div>
            <div className="table-wrap"><table>
              <thead><tr><th>Location</th><th>Risk score</th><th>Estimated population</th><th>Status</th></tr></thead>
              <tbody>{locations.map((loc) => <tr key={loc.name}>
                <td>{loc.name}</td><td><div className="risk-cell">
                  <div className="risk-track"><div style={{ width: `${loc.risk}%`, background: loc.risk >= 70 ? "#ef6b55" : "#e8a23d" }} /></div>{loc.risk}%
                </div></td>
                <td>{loc.people.toLocaleString()}</td>
                <td><span className={`risk-pill ${loc.risk >= 70 ? "danger" : "warning"}`}>{loc.risk >= 70 ? "High" : "Moderate"}</span></td>
              </tr>)}</tbody>
            </table></div>
          </section>
        </>}

        {page === "Simulation" && <section className="card page-panel"><h3>Simulation controls</h3><p>Choose a scenario and adjust rainfall on the Overview page.</p><button className="primary-button" onClick={() => setPage("Overview")}>Open simulation controls</button></section>}
        {page === "Cascade graph" && <section className="card page-panel"><h3>Hazard dependency graph</h3><p>Rainfall → Flood → Landslide → Infrastructure failure → Water contamination.</p><p>These are illustrative relationships, not validated predictions.</p></section>}
        {page === "Risk map" && <section className="card page-panel"><h3>Regional risk assessment</h3><div className="location-list">{locations.map((loc) => <div className="location-row" key={loc.name}><Map size={19} /><span>{loc.name}</span><strong>{loc.risk}%</strong></div>)}</div><p>Map locations are simulated and do not represent real coordinates.</p></section>}
        {page === "Resource allocation" && <section className="card page-panel"><h3>Emergency resource allocation</h3><p>Illustrative allocation based on the simulated risk score.</p>{resources.map((item, index) => <div className="resource-row" key={item.name}><div><strong>{item.name}</strong><p>{item.allocated} allocated / {item.available} available</p></div><input type="range" min="0" max={item.available} value={item.allocated} onChange={(e) => setResources((old) => old.map((r, i) => i === index ? { ...r, allocated: Number(e.target.value) } : r))} /></div>)}<button className="primary-button" onClick={() => window.print()}><FileText size={17} />Print allocation report</button></section>}
        {page === "Scenarios" && <section className="card page-panel"><h3>Scenario library</h3>{["Extreme rainfall", "River flooding", "Mountain landslide", "Coastal storm"].map((s) => <button className="scenario-button" key={s} onClick={() => { setScenario(s); setPage("Overview"); }}><CloudRain size={18} />{s} →</button>)}</section>}
        {page === "Alerts" && <section className="card page-panel"><h3>Simulated alerts</h3>{locations.filter((l) => l.risk >= 70).map((l) => <div className="alert-row" key={l.name}><AlertTriangle size={20} /><div><strong>{l.name}: elevated risk</strong><p>Review this location in the demonstration scenario.</p></div></div>)}</section>}
        {page === "Reports & audit" && <section className="card page-panel"><h3>Simulation report</h3><p>Scenario: {scenario}</p><p>Rainfall intensity: {rainfall} mm</p><p>Estimated cascade risk: {risk}%</p><p>Simulation run: {simulated ? "Completed" : "Not yet run"}</p><button className="primary-button" onClick={() => window.print()}><FileText size={17} />Print report</button></section>}
        <footer>CascadeGuard · Research prototype · Synthetic data only</footer>
      </main>
    </div>
  );
}
